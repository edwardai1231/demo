<?php

//create for the inventory of the pizza sotre
function get_undelivered_orders($db) {

    $query = 'SELECT * FROM undelivered_orders';
    $statement = $db->prepare($query);
    $statement->execute();
    $undelivered_orders = $statement->fetchAll();
    $statement->closeCursor();
    return $undelivered_orders;
}

//delete order 
function delete_undelivered_order($db, $orderID) {

    $query = 'DELETE FROM undelivered_orders WHERE orderId = :id';
    $statement = $db->prepare($query);
    $statement->bindValue(':id', $orderID);
    $statement->execute();
    $statement->closeCursor();
}

//add order 
function add_undelivered_order($db, $orderID, $flour, $cheese) {

    $query = 'INSERT INTO undelivered_orders (orderId, flour_qty, cheese_qty) 
                                        values (:id, :flour, :cheese)';
    $statement = $db->prepare($query);
    $statement->bindValue(':id', $orderID);
    $statement->bindValue(':flour', $flour);
    $statement->bindValue(':cheese', $cheese);
    $statement->execute();
    $statement->closeCursor();
}

//get inventory (cheese and flour)
function get_inventory($db) {

    $query = 'SELECT * FROM inventory';
    $statement = $db->prepare($query);
    $statement->execute();
    $inventory = $statement->fetchAll();
    $statement->closeCursor();
    return $inventory;
}

function add_supply_to_inventory($db, $flour_new, $cheese_new) {

    $inventory = get_inventory($db);
    // quantity of flour in inventory
    $flour = $inventory[0]['flour'];
    // quantity of cheese in inventory
    $cheese = $inventory[0]['cheese'];
    $new_flour = $flour + $flour_new;
    $new_cheese = $cheese + $cheese_new;

    $query = 'UPDATE inventory SET quantity = :f WHERE product_id = 11';
    $statement = $db->prepare($query);
    $statement->bindValue(':f', $new_flour);
    $statement->execute();
    $statement->closeCursor();

    $query = 'UPDATE inventory SET quantity = :c WHERE product_id = 12';
    $statement = $db->prepare($query);
    $statement->bindValue(':c', $new_cheese);
    $statement->execute();
    $statement->closeCursor();
}
function remove_inventory($db, $n){
    $inventory = get_inventory($db);
    // quantity of flour in inventory
    $flour = $inventory[0]['quantity'];
    // quantity of cheese in inventory
    $cheese = $inventory[1]['quantity'];
    $new_flour = $flour - $n;
    $new_cheese = $cheese - $n;


    
    $query = 'UPDATE inventory SET quantity = :f WHERE product_id = 11';
    $statement = $db->prepare($query);
    $statement->bindValue(':f', $new_flour);
    $statement->execute();
    $statement->closeCursor();

    $query = 'UPDATE inventory SET quantity = :c WHERE product_id = 12';
    $statement = $db->prepare($query);
    $statement->bindValue(':c', $new_cheese);
    $statement->execute();
    $statement->closeCursor();



}

function get_all_undelivered_orders($db) {
    $query = 'SELECT * FROM undelivered_orders';
    $statement = $db->prepare($query);
    $statement->execute();
    $undelivered_orders = $statement->fetchAll();
    $statement->closeCursor();
    return $undelivered_orders;
}

function update_inventory($db, $cheese_qty, $flour_qty) {
    $current_inventory = get_inventory();
    $new_flour_level = $current_inventory[0]['flour_qty'];
    $new_cheese_level = $current_inventory[0]['cheese_qty'];

    if ($flour_qty != null) { // Null values can occur when we place inventory order with just cheese
        $new_flour_level = $current_inventory[0]['flour_qty'] + $flour_qty;
    }

    if ($cheese_qty != null) { // Null values can occur when we place inventory order with just flour
        $new_cheese_level = $current_inventory[0]['cheese_qty'] + $cheese_qty;
    }

    if (($new_flour_level < 0) || ($new_cheese_level < 0)) {
        throw new Exception('Insufficient Inventory');
    } else {
        $query = 'UPDATE inventory SET cheese_qty = :new_cheeseQty, flour_qty = :new_flourQty';
        $statement = $db->prepare($query);
        $statement->bindValue(':new_cheeseQty', $new_cheese_level);
        $statement->bindValue(':new_flourQty', $new_flour_level);
        $statement->execute();
        $statement->closeCursor();
    }
}
function delete_delivered_order($db, $orderId) {
    $query = 'delete from undelivered_orders where orderId = :order_id';
    $statement = $db->prepare($query);
    $statement->bindValue(':order_id', $orderId);
    $statement->execute();
    $statement->closeCursor();
}
