<?php

function initial_db($db) {
    $query = 'delete from order_topping;';
    $query.='delete from pizza_orders;';
    $query.='delete from menu_sizes;';
    $query.='delete from menu_toppings;';
    $query.='delete from pizza_sys_tab;';
    $query.='delete from inventory;';
    $query.='delete from undelivered_orders;';

    $query.='insert into pizza_sys_tab values (1);';
    $query.="insert into menu_toppings values (1,'Pepperoni');";
    $query.="insert into menu_sizes values (1,'small');";
    $query.="insert into inventory(product_id, product_name, quantity) values (11, 'flour', 100);";
    $query.="insert into inventory(product_id, product_name, quantity) values (12, 'cheese', 100);";
    // TODO: reinitialize inventory, undelivered orders tables
    $statement = $db->prepare($query);
    $statement->execute();

    return $statement;
}
