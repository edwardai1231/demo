<?php
require('../../util/main.php');
require('../../model/database.php');
require('../../model/day_db.php');
require('../../model/initial.php');
require('../../model/inventory_db.php');
require('../../vendor/autoload.php');
require('web_services.php');
require('day_helpers.php');
// Note that you don't have to put all your code in this file.
// You can use another file day_helpers.php to hold helper functions
// and call them from here.

//code from ../..restclient/index.php
$spot = strpos($app_path, 'pizza2');
$part = substr($app_path, 0, $spot);
$base_url = $_SERVER['SERVER_NAME'] . $part . 'proj2_server/rest';

// Instantiate Guzzle HTTP client
$httpClient = new \GuzzleHttp\Client();

$action = filter_input(INPUT_POST, 'action');
if ($action == NULL) {
    $action = filter_input(INPUT_GET, 'action');
    if ($action == NULL) {
        $action = 'list';
    }
}
 $current_day = get_current_day($db);
if ($action == 'list') {
    try {
        $todays_orders = get_orders_for_day($db, $current_day);
        // Get undelivered orders
        $undelivered_orders = get_undelivered_orders($db);
        // Get inventory
        $inventorys = get_inventory($db);
    } catch (Exception $e) {
        include('../../errors/error.php');
        exit();
    }
    include('day_list.php');
} else if ($action == 'next_day') {
    try {
        finish_orders_for_day($db, $current_day);
        increment_day($db);
        post_day($httpClient, $base_url, $current_day+1);
        check_if_need_supply($db, $httpClient, $base_url);
        header("Location: .");
    } catch (Exception $e) {
        include('../../errors/error.php');
        exit();
    }
} else if ($action == 'initial_db') {
    try {
        initial_db($db);
        post_day($httpClient, $base_url, 0);
        check_if_need_supply($db, $httpClient, $base_url);
        header("Location: .");
    } catch (Exception $e) {
        include ('../../errors/error.php');
        exit();
    } 
}
?>