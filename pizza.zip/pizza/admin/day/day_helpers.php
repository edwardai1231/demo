<?php

// Use $server_orders vs. $undelivered_orders to find newly delivered orders
// Credit their newly delivered orders to inventory and delete such orders from 
// the undelivered_orders table
// $server_orders: array of orders from server
// $undelivered orders: array of orders from undelivered orders table
function record_deliveries($db, $server_orders, $undelivered_orders) {
    $delivered_orders = array();  // build set of delivered orders
    for ($i = 0; $i < count($server_orders); $i++) {
        $orderid = $server_orders[$i]['orderId'];
        $delivered = $server_orders[$i]['delivered'];
        if ($delivered) {
            $delivered_orders[$orderid] = $server_orders[$i];  // remember order by id
        }
    }
    error_log('server orders: ' . print_r($server_orders, true));
    error_log('delivered: ' . print_r($delivered_orders, true));
    // match delivered server order with previously undelivered order
    for ($j = 0; $j < count($undelivered_orders); $j++) {
        $orderID = $undelivered_orders[$j]['orderId'];
        error_log('looking at undel order ' . print_r($undelivered_orders[$j], true));
        if (array_key_exists($orderID, $delivered_orders)) {
            error_log("found newly delivered order $orderID");
            $order = $delivered_orders[$orderID];  // the full order info
            // TODO
            // delete $orderID from undelivered orders table
            // get the quantities of flour and cheese in this order
            // and add them to the inventory table
            if ($order['productID'] == 11) 
                $flour_qty = $order['quantity'];
            else if ($one_item['productID'] == 12) 
                $cheese_qty = $order['quantity'];

            add_supply_to_inventory($db, $flour_qty, $cheese_qty);

            delete_undelivered_order($db, $orderID);

        }
    }
}

// Put other helpers here, to keep only top-level code in index.php
function check_if_need_supply($db, $httpClient, $base_url)
{
    // Step 1: Get list of all underlivered orders
    $undeliverd_orders = get_all_undelivered_orders($db);
       
    foreach ($undeliverd_orders as $one_undeliverd_order) {

// Step 2: Get order status for each order using the web servers functions 
        $one_order = get_undeliverd_order($httpClient, $base_url, $one_undeliverd_order['orderId']);
        error_log('one_order: ' . print_r($one_order)); 
        
// Step 3: If order status is 'delivered', then update inventory and delete entry from undelivered table
        if ($one_order['delivered'] == true) {

//Step 3a: Update inventory
            foreach ($one_order['items'] as $one_item) {
                if ($one_item['productID'] == 11) {
                    $flour_units_update = $one_item['quantity'];
                } else if ($one_item['productID'] == 12) {
                    $cheese_units_update = $one_item['quantity'];
                }
            }
            update_inventory($db, $cheese_units_update, $flour_units_update);


//Step 3b: Delete entry from undelivered orders
            delete_delivered_order($db, $one_undeliverd_order['orderId']);
        }
    }
    // Array ( [0] => Array ( [flour] => 100 [0] => 100 [cheese] => 100 [1] => 100 ) )
    // $inventory[0]['quantity'] is to get flour quantity
    // $inventory[1]['quantity'] is to get cheese quantity
    $inventory = get_inventory($db);
    $undeliverd_orders_updated = get_all_undelivered_orders($db);
    //print_r($inventory);
    // quantity of flour in inventory
    $flour = $inventory[0]['quantity'];
    // quantity of cheese in inventory
    $cheese = $inventory[1]['quantity'];
    // variable for checking if need to place order 
    $need_to_place_order = false;
    // number of flour need to order
    $flour_to_order = 0;
    // number of cheese need to order
    $cheese_to_order = 0;

    if ($flour < 150 && ($undeliverd_orders_updated == null)){
        $need_to_place_order = true;
        $flour_to_order = 150 - $flour;
    }
    if ($cheese < 150 && ($undeliverd_orders_updated == null)){
        $need_to_place_order = true;
        $cheese_to_order = 150 - $cheese;
    }
    //echo 'cheese to order' . $cheese_to_order;
   // echo 'flour to order' . $flour_to_order;
    if($need_to_place_order == true)
    {
        $orderID = post_order($httpClient, $base_url, $flour_to_order, $cheese_to_order);
        add_undelivered_order($db, $orderID, $flour_to_order, $cheese_to_order);
    }
}