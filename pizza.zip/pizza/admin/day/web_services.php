<?php



// Functions to do the base web services needed
// Note that all needed web services are sent from this day directory
// The functions here should throw up to their callers, just like
// the functions in model.
//
// Post day number to server
// Returns if successful, or throws if not
function post_day($httpClient, $base_url, $day) {
    error_log('post_day to server: ' . $day);
    $url = $base_url . '/day/';
    $httpClient->request('POST', $url, ['json' => $day]);
}

function get_undeliverd_order($httpClient, $base_url, $order_id) {
    $url = 'http://' . $base_url . '/orders/' . $order_id;
    error_log('get_undeliverd_order from server Order ID: ' . $order_id . ' URL'. $url);
    
    $response = $httpClient->get($url);
    $orderJson = $response->getBody()->getContents();  // as StreamInterface, then string
    $order = json_decode($orderJson, true);
    return $order;
}
// TODO: POST order and get back location (i.e., get new id), get all orders 
// in server and/or get a specific order by orderid

function post_order($httpClient, $base_url, $flour, $cheese) {
    error_log('post_order to server number of flour: ' . $flour . 'number of cheese' . $cheese);
    $url =  'http://' . $base_url . '/orders/';
    // product id is 11 for flour and 12 for cheese cheese, customer ID 1, 2 or 3
    $item1 = array("productID" => 11, "quantity" => "$flour");
    $item2 = array("productID" => 12, "quantity" => "$cheese");
    $order = array("customerID" => 1, "items" => array($item1, $item2));
    //echo 'Post of order result: ' .  print_r($order);
    $response = $httpClient->request('POST', $url, ['json' => $order]);
    $location = $response->getHeader('Location');
    //echo "Location = ";
    //echo var_dump($location) . '<br>';
    $status = $response->getStatusCode();
    // Return the order ID
    // FIXME: Need to check status and take errors into account
    $spot1 = strripos($location[0], "/");
    $order_id = substr($location[0], $spot1+1);
    return $order_id; 
 }