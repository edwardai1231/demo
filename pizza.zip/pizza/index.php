<?php include 'util/main.php';
include 'view/header.php'; ?>
<main>
  <section>
        <h1>Home</h1>
    <ul>
        <li>
            <a href="admin">Shop Manager</a>
        </li>
        <li>
            <a href="pizza">Pizza Shop for Students</a>
        </li>
    </ul>
  </section>
</main>
<?php include 'view/footer.php'; 
