/*  File edit by Student:
                Wenxiu Ye
                Pooja Khare
    Description: added drop tables for inventory and undelivered_order
*/
-- for use where we can't drop the whole database
-- drop targets of FKs after tables with the FKs
-- if necessary, use --force to get past failing commands
drop table order_topping;	
drop table pizza_orders;
drop table menu_sizes;			
drop table menu_toppings;	
drop table status_values;
drop table pizza_sys_tab;
drop table undelivered_orders;
drop table inventory;



